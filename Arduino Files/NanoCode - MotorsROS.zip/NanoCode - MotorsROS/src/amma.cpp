/*
#include <Arduino.h>

#include <L298N.h>
#include <ros.h>
#include <std_msgs/Int32.h>

// Pin definition
const unsigned int IN1 = 8;
const unsigned int IN2 = 7;
const unsigned int EN = 9;

const unsigned int IN3 = 4;
const unsigned int IN4 = 5;
const unsigned int ENB = 3;

// int left_V_ros;
// int right_V_ros;

float left_V_ros_recieved;
float right_V_ros_recieved;

float PWM_left;
float PWM_right;

float V_Max = 0.5;

// Create one motor instance
L298N motor(EN, IN1, IN2);
L298N motorleft(ENB, IN3, IN4);

ros::NodeHandle nh;

void callBackFunctionMotorLeft(const std_msgs::Int32 &left_V_ros)
{
  left_V_ros_recieved = left_V_ros.data;
}

void callBackFunctionMotorRight(const std_msgs::Int32 &right_V_ros)
{
  right_V_ros_recieved = right_V_ros.data;
}

ros::Subscriber<std_msgs::Int32> leftMotorROSSSUB("vl", &callBackFunctionMotorLeft);

ros::Subscriber<std_msgs::Int32> rightMotorROSSSUB("vr", &callBackFunctionMotorRight);
void setup()
{
  nh.getHardware()->setBaud(9660);
  nh.initNode();

  nh.subscribe(leftMotorROSSSUB);
  nh.subscribe(rightMotorROSSSUB);
}

void loop()
{
  nh.spinOnce();
  motor.setSpeed((right_V_ros_recieved / V_Max) * 255);
  motorleft.setSpeed((left_V_ros_recieved / V_Max) * 255);

  // Tell the motor to go forward (may depend by your wiring)
  motor.forward();
  motorleft.forward();

  delay(100);

  // Stop
  //motor.stop();
  //motorleft.stop();
}

*/
