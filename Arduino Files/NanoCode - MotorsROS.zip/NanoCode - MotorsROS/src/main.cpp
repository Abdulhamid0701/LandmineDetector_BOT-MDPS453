
#include <Arduino.h>

#include <L298N.h>
#include <ros.h>
#include <std_msgs/Int32.h>

// Pin definition

#define left_motor_forward_pin 22
#define left_motor_backward_pin 24
#define left_motor_en_pin 8

#define right_motor_forward_pin 28
#define right_motor_backward_pin 26
#define right_motor_en_pin 7

/*
const int PIN_ENCOD_A_MOTOR_LEFT = 2;               //A channel for encoder of left motor                    
const int PIN_ENCOD_B_MOTOR_LEFT = 4;               //B channel for encoder of left motor

const int PIN_ENCOD_A_MOTOR_RIGHT = 3;              //A channel for encoder of right motor         
const int PIN_ENCOD_B_MOTOR_RIGHT = 5;              //B channel for encoder of right motor 

volatile float pos_left = 0;  // Left motor encoder position
volatile float pos_right = 0; // Right motor encoder position
*/


// int left_V_ros;
// int right_V_ros;

float left_V_ros_recieved;
float right_V_ros_recieved;


float PWM_left;
float PWM_right;

float V_Max = 13;

float current_micros;
float prev_micros;

// Create one motor instance
// L298N motor(EN, IN1, IN2);
// L298N motorleft(ENB, IN3, IN4);

/*

void encoderLeftMotor() {
  if (digitalRead(PIN_ENCOD_A_MOTOR_LEFT) == digitalRead(PIN_ENCOD_B_MOTOR_LEFT)) pos_left++;
  else pos_left--;
}

//Right motor encoder counter
void encoderRightMotor() {
  if (digitalRead(PIN_ENCOD_A_MOTOR_RIGHT) == digitalRead(PIN_ENCOD_B_MOTOR_RIGHT)) pos_right--;
  else pos_right++;
}
*/

ros::NodeHandle nh;

void callBackFunctionMotorLeft(const std_msgs::Int32 &left_V_ros)
{
  left_V_ros_recieved = left_V_ros.data;
}

void callBackFunctionMotorRight(const std_msgs::Int32 &right_V_ros)
{
  right_V_ros_recieved = right_V_ros.data;
}

ros::Subscriber<std_msgs::Int32> leftMotorROSSSUB("vl", &callBackFunctionMotorLeft);

ros::Subscriber<std_msgs::Int32> rightMotorROSSSUB("vr", &callBackFunctionMotorRight);
void setup()
{
  
  pinMode(right_motor_forward_pin, OUTPUT);
  pinMode(right_motor_backward_pin, OUTPUT);
  pinMode(right_motor_en_pin, OUTPUT);
  pinMode(left_motor_forward_pin, OUTPUT);
  pinMode(left_motor_backward_pin, OUTPUT);
  pinMode(left_motor_en_pin, OUTPUT);

  /*
  pinMode(PIN_ENCOD_A_MOTOR_LEFT, INPUT); 
  pinMode(PIN_ENCOD_B_MOTOR_LEFT, INPUT); 
  digitalWrite(PIN_ENCOD_A_MOTOR_LEFT, HIGH);                // turn on pullup resistor
  digitalWrite(PIN_ENCOD_B_MOTOR_LEFT, HIGH);
  attachInterrupt(0, encoderLeftMotor, RISING);

  // Define the rotary encoder for right motor
  pinMode(PIN_ENCOD_A_MOTOR_RIGHT, INPUT); 
  pinMode(PIN_ENCOD_B_MOTOR_RIGHT, INPUT); 
  digitalWrite(PIN_ENCOD_A_MOTOR_RIGHT, HIGH);                // turn on pullup resistor
  digitalWrite(PIN_ENCOD_B_MOTOR_RIGHT, HIGH);
  attachInterrupt(1, encoderRightMotor, RISING);
  */

  nh.getHardware()->setBaud(9600);
  nh.initNode();

  nh.subscribe(leftMotorROSSSUB);
  nh.subscribe(rightMotorROSSSUB);

  prev_micros = 0;
}

void loop()
{
  nh.spinOnce();

  // Set the speed based on the received velocity
  int right_speed = (right_V_ros_recieved / V_Max) * 255;
  int left_speed = (left_V_ros_recieved / V_Max) * 255;

  analogWrite(right_motor_en_pin, abs(right_speed)*0.7);
  analogWrite(left_motor_en_pin, abs(left_speed));

  // Set the direction based on the sign of the received velocity
  if (right_speed > 0)
  {
    digitalWrite(right_motor_forward_pin, HIGH);
    digitalWrite(right_motor_backward_pin, LOW);
  }
  else if (right_speed < 0)
  {
    digitalWrite(right_motor_forward_pin, LOW);
    digitalWrite(right_motor_backward_pin, HIGH);
  }
  else if (abs(right_speed) < 0.3)
  {
    digitalWrite(right_motor_forward_pin, HIGH);
    digitalWrite(right_motor_backward_pin, HIGH);
  }

  if (left_speed > 0)
  {
    digitalWrite(left_motor_forward_pin, HIGH);
    digitalWrite(left_motor_backward_pin, LOW);
  }
  else if (left_speed < 0)
  {
    digitalWrite(left_motor_forward_pin, LOW);
    digitalWrite(left_motor_backward_pin, HIGH);
  }
  else if (abs(left_speed) < 0.3)
  {
    digitalWrite(left_motor_forward_pin, HIGH);
    digitalWrite(left_motor_backward_pin, HIGH);
  }

  delay(1);
}
